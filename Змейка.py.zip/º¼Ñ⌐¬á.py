
import pygame
import random
import time

# Инициализация Pygame
pygame.init()

# Параметры экрана
WIDTH, HEIGHT = 600, 600
CELL_SIZE = 30
GRID_WIDTH = WIDTH // CELL_SIZE
GRID_HEIGHT = HEIGHT // CELL_SIZE

# Цвета
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Настройки игры
FPS = 10
clock = pygame.time.Clock()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Змейка")

# Начальное состояние змеи
snake = [(5, 5), (4, 5), (3, 5)]  # список кортежей (x, y)
direction = (1, 0)  # начальное направление: вправо
food = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))
score = 0

# Флаг игры
running = True
game_over = False

def draw_grid():
    for x in range(0, WIDTH, CELL_SIZE):
        pygame.draw.line(screen, WHITE, (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT, CELL_SIZE):
        pygame.draw.line(screen, WHITE, (0, y), (WIDTH, y))

def place_food():
    while True:
        new_food = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))
        if new_food not in snake:
            return new_food

while running:
    screen.fill(BLACK)
    draw_grid()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if game_over:
                if event.key == pygame.K_r:
                    # Перезапуск игры
                    snake = [(5, 5), (4, 5), (3, 5)]
                    direction = (1, 0)
                    food = place_food()
                    score = 0
                    game_over = False
            else:
                # Управление
                if event.key == pygame.K_UP and direction != (0, 1):
                    direction = (0, -1)
                elif event.key == pygame.K_DOWN and direction != (0, -1):
                    direction = (0, 1)
                elif event.key == pygame.K_LEFT and direction != (1, 0):
                    direction = (-1, 0)
                elif event.key == pygame.K_RIGHT and direction != (-1, 0):
                    direction = (1, 0)

    if not game_over:
        # Движение змеи
        head_x, head_y = snake[0]
        dx, dy = direction
        new_head = ((head_x + dx) % GRID_WIDTH, (head_y + dy) % GRID_HEIGHT)  # зацикливание

        # Проверка на столкновение с собой
        if new_head in snake:
            game_over = True

        snake.insert(0, new_head)

        # Проверка на поедание еды
        if new_head == food:
            food = place_food()
            score += 1
        else:
            snake.pop()  # удаляем хвост, если не съели еду

    # Отрисовка змеи
    for segment in snake:
        x, y = segment
        pygame.draw.rect(screen, GREEN, (x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE))

    # Отрисовка еды
    fx, fy = food
    pygame.draw.rect(screen, RED, (fx * CELL_SIZE, fy * CELL_SIZE, CELL_SIZE, CELL_SIZE))

    # Отображение счёта
    font = pygame.font.SysFont("Arial", 24)
    score_text = font.render(f"Счёт: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

    # Сообщение об окончании игры
    if game_over:
        over_text = font.render("Игра окончена! Нажмите R для перезапуска", True, WHITE)
        screen.blit(over_text, (WIDTH // 2 - 200, HEIGHT // 2))

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()